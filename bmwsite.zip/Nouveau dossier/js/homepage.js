document.addEventListener('DOMContentLoaded', () => {
    const modelCards = document.querySelectorAll('.model-card');
    const modal = document.getElementById('model-modal');
    const modalTitle = document.getElementById('model-title');
    const modalDetails = document.getElementById('model-details');
    const closeModal = document.querySelector('.close');

    const modelData = {
        '3 Series': {
            title: 'BMW Série 3',
            details: 'Prix: 41 250 €\nCaractéristiques: 255 ch, 0-100 km/h en 5,3 secondes, 26/36 mpg\nFonctionnalités: Design sportif, technologie avancée, intérieur luxueux.'
        },
        'X5': {
            title: 'BMW X5',
            details: 'Prix: 59 400 €\nCaractéristiques: 335 ch, 0-100 km/h en 5,3 secondes, 21/26 mpg\nFonctionnalités: Intérieur spacieux, moteur puissant, fonctionnalités de sécurité avancées.'
        },
        'i8': {
            title: 'BMW i8',
            details: 'Prix: 147 500 €\nCaractéristiques: 369 ch, 0-100 km/h en 4,2 secondes, 69 MPGe\nFonctionnalités: Design futuriste, groupe motopropulseur hybride, technologie de pointe.'
        }
    };

    modelCards.forEach(card => {
        card.addEventListener('click', () => {
            const model = card.getAttribute('data-model');
            modalTitle.textContent = modelData[model].title;
            modalDetails.textContent = modelData[model].details;
            modal.style.display = 'block';
        });
    });

    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });

    // Configurator functionality
    const carPreview = document.getElementById('car-preview');
    const modelOptions = document.querySelectorAll('.model-option');
    const colorOptions = document.querySelectorAll('.color-option');

    let selectedModel = '3 Series'; // Default model
    let selectedColor = 'white'; // Default color

    modelOptions.forEach(option => {
        option.addEventListener('click', () => {
            selectedModel = option.getAttribute('data-model');
            updateCarPreview();
            modelOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
        });
    });

    colorOptions.forEach(option => {
        option.addEventListener('click', () => {
            selectedColor = option.getAttribute('data-color');
            updateCarPreview();
            colorOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
        });
    });

    function updateCarPreview() {
        carPreview.src = `../img/BMW-${selectedModel.replace(' ', '-')}-${selectedColor}.png`;
    }

    // Scroll animation
    const scrollElements = document.querySelectorAll('.scroll-animation');

    const elementInView = (el, dividend = 1) => {
        const elementTop = el.getBoundingClientRect().top;
        return (
            elementTop <= (window.innerHeight || document.documentElement.clientHeight) / dividend
        );
    };

    const displayScrollElement = (element) => {
        element.classList.add('visible');
    };

    const hideScrollElement = (element) => {
        element.classList.remove('visible');
    };

    const handleScrollAnimation = () => {
        scrollElements.forEach((el) => {
            if (elementInView(el, 1.25)) {
                displayScrollElement(el);
            } else {
                hideScrollElement(el);
            }
        });
    };

    window.addEventListener('scroll', () => {
        handleScrollAnimation();
    });

    handleScrollAnimation(); // Initial check
});

function findDealership() {
    const locationInput = document.getElementById('location-input').value;
    // Implement the logic to find and display dealerships based on the location input
    console.log(`Finding dealerships near: ${locationInput}`);
}